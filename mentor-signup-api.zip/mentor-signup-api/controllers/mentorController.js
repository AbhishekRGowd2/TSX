const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { validationResult } = require('express-validator');
const Mentor = require('../models/mentor');

// POST /mentors/signup
exports.signup = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  console.log("Request Body : ", req.body);
  const { name, email, password, skills } = req.body;
  if (!name || !email || !password || !skills) {
    console.log("Missing required fields");
}


  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const skillsString = skills.join(', ');
    const mentor = await Mentor.create({ name, email, password: hashedPassword, skills: skillsString});
    
    const token = jwt.sign({ id: mentor.id }, process.env.JWT_SECRET, { expiresIn: '1h' });
    res.status(201).json({ token, mentor: { name: mentor.name, email: mentor.email, skills: mentor.skills } });
  }catch (error) {
    console.error('Error during signup:', error); // Log the error details
    res.status(500).json({ error: 'Signup failed!!! ' });
}
 
};

// GET /mentors/:id
exports.getMentor = async (req, res) => {
  try {
    const mentor = await Mentor.findByPk(req.params.id, { attributes: { exclude: ['password'] } });
    if (!mentor) {
      return res.status(404).json({ error: 'Mentor not found' });
    }
    res.status(200).json(mentor);
  } catch (error) {
    res.status(500).json({ error: 'Failed to retrieve mentor details' });
  }
};
