const express = require('express');
const { body } = require('express-validator');
const mentorController = require('../controllers/mentorcontroller');
const router = express.Router();

// POST /mentors/signup
router.post(
  '/signup',
  [
    body('email').isEmail().withMessage('Invalid email'),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters long'),
    body('name').notEmpty().withMessage('Name is required')
  ],
  mentorController.signup
);

// GET /mentors/:id
router.get('/:id', mentorController.getMentor);

module.exports = router;
