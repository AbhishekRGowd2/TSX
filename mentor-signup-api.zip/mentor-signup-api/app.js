const express = require('express');
const helmet = require('helmet');
const morgan = require('morgan');
const sequelize = require('./config/database');
const mentorRoutes = require('./routes/mentorRoutes');

const app = express();
require('dotenv').config();

// Middlewares
app.use(helmet());
app.use(morgan('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/mentors', mentorRoutes);

// Test DB connection
sequelize.sync().then(() => console.log('Database connected'));

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
